import { pgTable, text, serial, integer, boolean, timestamp, numeric, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  hourlyRate: numeric("hourly_rate").notNull().default("50"),
  logo: text("logo"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Client schema
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  company: text("company"),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
});

// Project schema
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  hourlyRate: numeric("hourly_rate"),
  active: boolean("active").notNull().default(true),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
});

// Time Entry schema
export const timeEntries = pgTable("time_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  projectId: integer("project_id").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // duration in seconds
  invoiceId: integer("invoice_id"),
});

export const insertTimeEntrySchema = createInsertSchema(timeEntries).omit({
  id: true,
  duration: true,
  invoiceId: true,
});

// Invoice schema
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  clientId: integer("client_id").notNull(),
  invoiceNumber: text("invoice_number").notNull(),
  issueDate: timestamp("issue_date").notNull(),
  dueDate: timestamp("due_date").notNull(),
  status: text("status").notNull().default("pending"), // pending, paid, overdue
  totalAmount: numeric("total_amount").notNull(),
  notes: text("notes"),
  items: json("items").notNull().$type<InvoiceItem[]>(), // JSON array of line items
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
});

// Settings schema
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  companyName: text("company_name"),
  companyAddress: text("company_address"),
  companyEmail: text("company_email"),
  companyPhone: text("company_phone"),
  defaultHourlyRate: numeric("default_hourly_rate").default("50"),
  defaultInvoiceNotes: text("default_invoice_notes"),
  invoicePrefix: text("invoice_prefix").default("INV-"),
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type TimeEntry = typeof timeEntries.$inferSelect;
export type InsertTimeEntry = z.infer<typeof insertTimeEntrySchema>;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

// Custom types
export interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

// Extended schemas for validation
export const timeEntryFormSchema = insertTimeEntrySchema.extend({
  projectId: z.number({
    required_error: "Please select a project",
  }),
  startTime: z.date({
    required_error: "Start time is required",
  }),
  endTime: z.date().optional(),
});

export const clientFormSchema = insertClientSchema.extend({
  name: z.string().min(1, "Client name is required"),
  email: z.string().email("Invalid email").optional().or(z.literal('')),
});

export const projectFormSchema = insertProjectSchema.extend({
  name: z.string().min(1, "Project name is required"),
  clientId: z.number({
    required_error: "Please select a client",
  }),
});

export const invoiceFormSchema = insertInvoiceSchema.extend({
  clientId: z.number({
    required_error: "Please select a client",
  }),
  items: z.array(
    z.object({
      description: z.string().min(1, "Description is required"),
      quantity: z.number().min(0.1, "Quantity must be greater than 0"),
      rate: z.number().min(0, "Rate must be a positive number"),
      amount: z.number().min(0, "Amount must be a positive number"),
    })
  ).min(1, "At least one item is required"),
});
