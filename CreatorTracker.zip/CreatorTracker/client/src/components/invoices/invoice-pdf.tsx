import React from "react";
import { jsPDF } from "jspdf";
import autoTable from 'jspdf-autotable';
import { Invoice, Client, Settings, InvoiceItem } from "@shared/schema";
import { formatCurrency } from "@/lib/format";
import { format } from "date-fns";

interface InvoicePdfProps {
  invoice: Invoice;
  client: Client;
  settings: Settings;
}

export const generateInvoicePdf = ({ invoice, client, settings }: InvoicePdfProps): jsPDF => {
  // Create a new PDF document
  const doc = new jsPDF();
  
  // Set document properties
  doc.setProperties({
    title: `Invoice ${invoice.invoiceNumber}`,
    subject: 'Invoice',
    author: settings.companyName,
    creator: 'TimeTrack Pro',
  });

  // Add company information at the top
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text(settings.companyName || 'Your Company', 20, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  let yPos = 30;
  if (settings.companyAddress) {
    const addressLines = settings.companyAddress.split('\n');
    addressLines.forEach(line => {
      doc.text(line, 20, yPos);
      yPos += 5;
    });
  }
  if (settings.companyEmail) {
    doc.text(`Email: ${settings.companyEmail}`, 20, yPos);
    yPos += 5;
  }
  if (settings.companyPhone) {
    doc.text(`Phone: ${settings.companyPhone}`, 20, yPos);
    yPos += 5;
  }

  // Add invoice details on the right
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('INVOICE', 170, 20, { align: 'right' });
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Invoice #: ${invoice.invoiceNumber}`, 170, 30, { align: 'right' });
  doc.text(`Issue Date: ${format(new Date(invoice.issueDate), 'MMM d, yyyy')}`, 170, 35, { align: 'right' });
  doc.text(`Due Date: ${format(new Date(invoice.dueDate), 'MMM d, yyyy')}`, 170, 40, { align: 'right' });
  
  // Add status
  doc.setFontSize(10);
  let statusColor;
  switch (invoice.status) {
    case 'paid':
      statusColor = [0, 128, 0]; // Green
      break;
    case 'pending':
      statusColor = [255, 165, 0]; // Orange
      break;
    case 'overdue':
      statusColor = [255, 0, 0]; // Red
      break;
    default:
      statusColor = [128, 128, 128]; // Gray
  }
  doc.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
  doc.text(`Status: ${invoice.status.toUpperCase()}`, 170, 45, { align: 'right' });
  doc.setTextColor(0, 0, 0); // Reset to black

  // Add bill to section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Bill To:', 20, 65);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(client.name, 20, 72);
  if (client.company) doc.text(client.company, 20, 77);
  if (client.address) {
    const addressLines = client.address.split('\n');
    let addrY = 82;
    addressLines.forEach(line => {
      doc.text(line, 20, addrY);
      addrY += 5;
    });
  }
  if (client.email) doc.text(`Email: ${client.email}`, 20, 97);
  if (client.phone) doc.text(`Phone: ${client.phone}`, 20, 102);

  // Add invoice items table
  const tableColumn = ["Item", "Description", "Qty", "Rate", "Amount"];
  const tableRows = invoice.items.map((item: InvoiceItem) => [
    '',
    item.description,
    item.quantity.toString(),
    formatCurrency(item.rate),
    formatCurrency(item.amount)
  ]);

  autoTable(doc, {
    startY: 115,
    head: [tableColumn],
    body: tableRows,
    headStyles: {
      fillColor: [59, 130, 246], // Blue color
      textColor: 255,
      fontStyle: 'bold'
    },
    foot: [
      ['', '', '', 'Subtotal', formatCurrency(Number(invoice.totalAmount))],
      ['', '', '', 'Tax', formatCurrency(0)],
      ['', '', '', 'Total', formatCurrency(Number(invoice.totalAmount))]
    ],
    footStyles: {
      fillColor: [245, 245, 245],
      textColor: 0,
      fontStyle: 'bold'
    },
    theme: 'grid',
    styles: {
      fontSize: 10
    },
    columnStyles: {
      0: { cellWidth: 20 },
      1: { cellWidth: 80 },
      2: { cellWidth: 25, halign: 'center' },
      3: { cellWidth: 30, halign: 'right' },
      4: { cellWidth: 30, halign: 'right' },
    }
  });

  // Add notes if present
  if (invoice.notes) {
    const finalY = (doc as any).lastAutoTable.finalY + 10;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Notes:', 20, finalY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(invoice.notes, 20, finalY + 7);
  }

  // Add footer
  const pageCount = doc.getNumberOfPages();
  doc.setFontSize(8);
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.text(`Page ${i} of ${pageCount}`, 105, 287, { align: 'center' });
    doc.text('Thank you for your business!', 105, 292, { align: 'center' });
  }

  return doc;
};

// Component for React to generate and download the PDF
export function InvoicePdf({ invoice, client, settings }: InvoicePdfProps) {
  const handleDownload = () => {
    const doc = generateInvoicePdf({ invoice, client, settings });
    doc.save(`Invoice-${invoice.invoiceNumber}.pdf`);
  };

  return (
    <button 
      onClick={handleDownload}
      className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
    >
      Download Invoice PDF
    </button>
  );
}
