import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { PlayIcon, PauseIcon, Pause } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatTime } from "@/lib/format";
import { useToast } from "@/hooks/use-toast";
import { Project } from "@shared/schema";

interface TimerControlProps {
  userId?: number;
}

export function TimerControl({ userId = 1 }: TimerControlProps) {
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const timerRef = useRef<number | null>(null);
  const { toast } = useToast();

  // Fetch projects
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects", { userId }],
    enabled: !!userId,
  });

  // Create time entry mutation
  const createTimeEntry = useMutation({
    mutationFn: async (data: {
      userId: number;
      projectId: number;
      description: string;
      startTime: Date;
      endTime: Date;
    }) => {
      const response = await apiRequest("POST", "/api/time-entries", data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      toast({
        title: "Time entry saved",
        description: "Your time entry has been successfully recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save time entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
  };

  const handleStartTimer = () => {
    if (!selectedProject) {
      toast({
        title: "Project required",
        description: "Please select a project before starting the timer.",
        variant: "destructive",
      });
      return;
    }

    const now = new Date();
    setStartTime(now);
    setIsTimerRunning(true);
    
    // Start the timer
    timerRef.current = window.setInterval(() => {
      setElapsedTime((prev) => prev + 1);
    }, 1000);
  };

  const handlePauseTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsTimerRunning(false);
  };

  const handleStopTimer = () => {
    if (!startTime || !selectedProject) return;

    handlePauseTimer();
    
    const endTime = new Date();
    
    // Save the time entry
    createTimeEntry.mutate({
      userId: userId,
      projectId: parseInt(selectedProject),
      description: description,
      startTime: startTime,
      endTime: endTime,
    });

    // Reset timer
    setElapsedTime(0);
    setStartTime(null);
    setDescription("");
  };

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Current Timer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="sm:w-1/3">
            <Select
              value={selectedProject}
              onValueChange={handleProjectChange}
              disabled={isTimerRunning}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a project" />
              </SelectTrigger>
              <SelectContent>
                {projectsLoading ? (
                  <SelectItem value="loading" disabled>
                    Loading projects...
                  </SelectItem>
                ) : (
                  projects?.map((project) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div className="sm:w-1/3">
            <Input
              type="text"
              placeholder="Description (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={isTimerRunning}
            />
          </div>
          
          <div className="mt-3 sm:mt-0 flex items-center justify-between sm:w-1/3">
            <div className="text-3xl font-mono font-medium tracking-wider text-gray-900 w-40 text-center">
              {formatTime(elapsedTime)}
            </div>
            
            <div className="flex space-x-2">
              {!isTimerRunning ? (
                <Button 
                  onClick={handleStartTimer}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <PlayIcon className="h-5 w-5 mr-2" />
                  Start
                </Button>
              ) : (
                <>
                  <Button 
                    onClick={handlePauseTimer}
                    variant="outline"
                  >
                    <PauseIcon className="h-5 w-5 mr-2" />
                    Pause
                  </Button>
                  <Button 
                    onClick={handleStopTimer}
                    variant="destructive"
                  >
                    <Pause className="h-5 w-5 mr-2" />
                    Stop
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
