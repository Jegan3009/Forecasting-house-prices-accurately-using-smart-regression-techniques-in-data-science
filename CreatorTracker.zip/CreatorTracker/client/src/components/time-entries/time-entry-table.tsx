import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";
import { TimeEntry, Project, Client } from "@shared/schema";
import { formatDuration } from "@/lib/format";
import { format } from "date-fns";

interface TimeEntryTableProps {
  timeEntries: TimeEntry[];
  projects: Project[];
  clients?: Client[];
  onEditEntry: (entry: TimeEntry) => void;
  onDeleteEntry: (entry: TimeEntry) => void;
}

export function TimeEntryTable({
  timeEntries,
  projects,
  clients = [],
  onEditEntry,
  onDeleteEntry,
}: TimeEntryTableProps) {
  // Get project by ID
  const getProjectInfo = (projectId: number) => {
    const project = projects.find((project) => project.id === projectId);
    if (!project) return { name: "Unknown Project", clientName: "Unknown Client" };

    const client = clients.find((client) => client.id === project.clientId);
    const clientName = client ? client.name : "Unknown Client";

    return {
      name: project.name,
      clientName,
    };
  };

  return (
    <div className="w-full overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Project</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {timeEntries.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  No time entries found
                </TableCell>
              </TableRow>
            ) : (
              timeEntries.map((entry) => {
                const projectInfo = getProjectInfo(entry.projectId);
                const startDate = new Date(entry.startTime);
                let durationDisplay = "In progress";
                
                if (entry.duration) {
                  durationDisplay = formatDuration(entry.duration);
                } else if (entry.endTime) {
                  const endDate = new Date(entry.endTime);
                  const durationSeconds = Math.floor((endDate.getTime() - startDate.getTime()) / 1000);
                  durationDisplay = formatDuration(durationSeconds);
                }

                return (
                  <TableRow key={entry.id}>
                    <TableCell>
                      <div className="font-medium">{projectInfo.name}</div>
                      <div className="text-sm text-gray-500">{projectInfo.clientName}</div>
                    </TableCell>
                    <TableCell>{entry.description || "—"}</TableCell>
                    <TableCell>
                      <div className="font-medium">{format(startDate, "MMM d, yyyy")}</div>
                      <div className="text-sm text-gray-500">
                        {format(startDate, "h:mm a")}
                        {entry.endTime && ` - ${format(new Date(entry.endTime), "h:mm a")}`}
                      </div>
                    </TableCell>
                    <TableCell>{durationDisplay}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEditEntry(entry)}
                        className="h-8 w-8"
                      >
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDeleteEntry(entry)}
                        className="h-8 w-8 text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
