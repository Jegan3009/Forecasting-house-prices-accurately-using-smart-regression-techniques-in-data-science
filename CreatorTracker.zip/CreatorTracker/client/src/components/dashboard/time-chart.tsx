import React, { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Chart from "chart.js/auto";

interface TimeChartProps {
  data: {
    projectId: number;
    projectName: string;
    duration: number;
  }[];
  isLoading?: boolean;
}

export function TimeChart({ data, isLoading }: TimeChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  // Convert seconds to hours for display
  const formatDuration = (seconds: number) => {
    return (seconds / 3600).toFixed(1);
  };

  useEffect(() => {
    if (isLoading || !chartRef.current) {
      return;
    }

    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    // Prepare data for the chart
    const labels = data.map((item) => item.projectName);
    const values = data.map((item) => parseFloat(formatDuration(item.duration)));

    // Define colors for the chart
    const backgroundColors = [
      "#3B82F6", // blue-500
      "#10B981", // emerald-500
      "#8B5CF6", // violet-500
      "#F59E0B", // amber-500
      "#EF4444", // red-500
      "#6366F1", // indigo-500
      "#EC4899", // pink-500
      "#14B8A6", // teal-500
    ];

    // Create a new chart
    const ctx = chartRef.current.getContext("2d");
    if (ctx) {
      chartInstance.current = new Chart(ctx, {
        type: "doughnut",
        data: {
          labels,
          datasets: [
            {
              label: "Hours Spent",
              data: values,
              backgroundColor: backgroundColors.slice(0, data.length),
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "right",
              labels: {
                boxWidth: 12,
                padding: 15,
              },
            },
            tooltip: {
              callbacks: {
                label: function (context) {
                  const label = context.label || "";
                  const value = context.parsed || 0;
                  return `${label}: ${value} hours`;
                },
              },
            },
          },
        },
      });
    }

    // Cleanup on unmount
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, isLoading]);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Time Distribution</CardTitle>
        </CardHeader>
        <CardContent className="h-72 flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-32 w-32 bg-gray-200 rounded-full mb-4"></div>
            <div className="h-4 w-40 bg-gray-200 rounded mb-2"></div>
            <div className="h-4 w-32 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Time Distribution</CardTitle>
      </CardHeader>
      <CardContent className="h-72">
        {data.length === 0 ? (
          <div className="h-full flex items-center justify-center">
            <p className="text-muted-foreground">No time data available for the selected period</p>
          </div>
        ) : (
          <canvas ref={chartRef}></canvas>
        )}
      </CardContent>
    </Card>
  );
}
