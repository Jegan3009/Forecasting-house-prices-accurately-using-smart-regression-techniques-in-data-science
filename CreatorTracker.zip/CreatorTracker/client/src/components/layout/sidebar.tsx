import React from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Clock,
  FileText,
  Users,
  BarChart,
  Settings as SettingsIcon,
  Home,
  LineChart,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

interface SidebarProps {
  user: {
    name: string;
    plan?: string;
    avatar?: string;
  };
}

export function Sidebar({ user }: SidebarProps) {
  const [location] = useLocation();

  const navigationItems = [
    {
      name: "Dashboard",
      href: "/",
      icon: LayoutDashboard,
    },
    {
      name: "Time Tracking",
      href: "/time-tracking",
      icon: Clock,
    },
    {
      name: "Invoices",
      href: "/invoices",
      icon: FileText,
    },
    {
      name: "Clients",
      href: "/clients",
      icon: Users,
    },
    {
      name: "Analytics",
      href: "/analytics",
      icon: BarChart,
    },
    {
      name: "House Price Forecasting",
      href: "/house-price-forecasting",
      icon: LineChart,
    },
    {
      name: "Settings",
      href: "/settings",
      icon: SettingsIcon,
    },
  ];

  return (
    <aside className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 bg-gray-800">
        <div className="px-4 py-6">
          <div className="flex items-center">
            <div className="rounded-full bg-blue-500 w-10 h-10 flex items-center justify-center text-white font-bold">
              TT
            </div>
            <span className="ml-3 text-white font-semibold text-lg">TimeTrack Pro</span>
          </div>
        </div>
        <div className="flex-1 flex flex-col py-4 overflow-y-auto">
          <nav className="flex-1 px-2 space-y-1">
            {navigationItems.map((item) => (
              <div key={item.href}>
                <Link href={item.href}>
                  <div
                    className={cn(
                      "flex items-center px-2 py-2 rounded-md group cursor-pointer",
                      location === item.href
                        ? "text-white bg-gray-900"
                        : "text-gray-300 hover:bg-gray-700 hover:text-white"
                    )}
                  >
                    <item.icon
                      className={cn(
                        "mr-3 flex-shrink-0 h-6 w-6",
                        location === item.href
                          ? "text-gray-300"
                          : "text-gray-400 group-hover:text-gray-300"
                      )}
                    />
                    {item.name}
                  </div>
                </Link>
              </div>
            ))}
          </nav>
        </div>
        <div className="px-4 py-4 border-t border-gray-700">
          <div className="flex items-center">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="bg-blue-500">
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium text-white">{user.name}</p>
              <p className="text-xs font-medium text-gray-300">{user.plan || "Pro Plan"}</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
