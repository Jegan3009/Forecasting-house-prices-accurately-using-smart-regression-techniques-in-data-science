import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/layout/sidebar";
import { MobileNav } from "@/components/layout/mobile-nav";
import Dashboard from "@/pages/dashboard";
import TimeTracking from "@/pages/time-tracking";
import Invoices from "@/pages/invoices";
import Clients from "@/pages/clients";
import Analytics from "@/pages/analytics";
import Settings from "@/pages/settings";
import HousePriceForecasting from "@/pages/house-price-forecasting";
import NotFound from "@/pages/not-found";
import { useQuery } from "@tanstack/react-query";

function App() {
  // Fetch demo user info for the sidebar
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/demo-user"],
  });

  const defaultUser = {
    name: "Sarah Johnson",
    plan: "Pro Plan",
  };

  // The main content with navigation
  const AppContent = () => (
    <div className="flex h-screen overflow-hidden">
      <Sidebar user={user || defaultUser} />
      <MobileNav user={user || defaultUser} />
      <div className="flex flex-col flex-1 overflow-y-auto md:ml-0 pt-16 md:pt-0">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/time-tracking" component={TimeTracking} />
          <Route path="/invoices" component={Invoices} />
          <Route path="/invoices/:id">
            {(params) => <Invoices invoiceId={params.id} />}
          </Route>
          <Route path="/invoices/edit/:id">
            {(params) => <Invoices edit invoiceId={params.id} />}
          </Route>
          <Route path="/invoices/:id/download">
            {(params) => <Invoices download invoiceId={params.id} />}
          </Route>
          <Route path="/clients" component={Clients} />
          <Route path="/analytics" component={Analytics} />
          <Route path="/settings" component={Settings} />
          <Route path="/house-price-forecasting" component={HousePriceForecasting} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );

  return (
    <TooltipProvider>
      <Toaster />
      <AppContent />
    </TooltipProvider>
  );
}

export default App;
