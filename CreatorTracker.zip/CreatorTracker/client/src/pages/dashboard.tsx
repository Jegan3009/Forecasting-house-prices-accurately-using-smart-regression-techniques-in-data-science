import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Clock,
  DollarSign,
  FolderOpen,
  Users,
  FileText,
  Plus,
} from "lucide-react";
import { StatsCard } from "@/components/dashboard/stats-card";
import { TimeChart } from "@/components/dashboard/time-chart";
import { TimeEntryTable } from "@/components/time-entries/time-entry-table";
import { InvoiceTable } from "@/components/invoices/invoice-table";
import { TimerControl } from "@/components/timer/timer-control";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import { Link, useLocation } from "wouter";
import { TimeEntry, Project, Client, Invoice } from "@shared/schema";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Dashboard() {
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [selectedTimeEntry, setSelectedTimeEntry] = useState<TimeEntry | null>(null);
  const [showDeleteInvoiceDialog, setShowDeleteInvoiceDialog] = useState(false);
  const [showDeleteTimeEntryDialog, setShowDeleteTimeEntryDialog] = useState(false);
  const [, navigate] = useLocation();

  // Fetch user stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/analytics/stats"],
  });

  // Fetch time distribution data
  const { data: timeDistribution, isLoading: distributionLoading } = useQuery({
    queryKey: ["/api/analytics/time-distribution"],
  });

  // Fetch time entries
  const { data: timeEntries, isLoading: entriesLoading } = useQuery<TimeEntry[]>({
    queryKey: ["/api/time-entries"],
  });

  // Fetch projects
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Fetch clients
  const { data: clients, isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Fetch invoices
  const { data: invoices, isLoading: invoicesLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const handleEditTimeEntry = (entry: TimeEntry) => {
    navigate(`/time-tracking?edit=${entry.id}`);
  };

  const handleDeleteTimeEntry = (entry: TimeEntry) => {
    setSelectedTimeEntry(entry);
    setShowDeleteTimeEntryDialog(true);
  };

  const confirmDeleteTimeEntry = async () => {
    if (selectedTimeEntry) {
      try {
        await fetch(`/api/time-entries/${selectedTimeEntry.id}`, {
          method: "DELETE",
        });
        // Invalidate and refetch
        await fetch("/api/time-entries");
        setShowDeleteTimeEntryDialog(false);
      } catch (error) {
        console.error("Error deleting time entry:", error);
      }
    }
  };

  const handleViewInvoice = (invoice: Invoice) => {
    navigate(`/invoices/${invoice.id}`);
  };

  const handleEditInvoice = (invoice: Invoice) => {
    navigate(`/invoices/edit/${invoice.id}`);
  };

  const handleDeleteInvoice = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setShowDeleteInvoiceDialog(true);
  };

  const confirmDeleteInvoice = async () => {
    if (selectedInvoice) {
      try {
        await fetch(`/api/invoices/${selectedInvoice.id}`, {
          method: "DELETE",
        });
        // Invalidate and refetch
        await fetch("/api/invoices");
        setShowDeleteInvoiceDialog(false);
      } catch (error) {
        console.error("Error deleting invoice:", error);
      }
    }
  };

  const handleDownloadInvoice = (invoice: Invoice) => {
    navigate(`/invoices/${invoice.id}/download`);
  };

  return (
    <div className="flex-1 relative pb-8 z-0 overflow-y-auto">
      {/* Page header */}
      <div className="bg-white shadow">
        <div className="px-4 sm:px-6 lg:max-w-6xl lg:mx-auto lg:px-8">
          <div className="py-6 md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Dashboard
              </h2>
            </div>
            <div className="mt-4 flex md:mt-0 md:ml-4">
              <Button asChild>
                <Link href="/time-tracking">
                  <Plus className="-ml-1 mr-2 h-5 w-5" />
                  Start New Timer
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Stats cards */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <StatsCard
              title="Total Hours This Month"
              value={statsLoading ? "Loading..." : `${stats?.totalHoursThisMonth}`}
              icon={Clock}
              iconColor="bg-blue-500"
              linkHref="/time-tracking"
            />
            <StatsCard
              title="Total Earnings This Month"
              value={statsLoading ? "Loading..." : formatCurrency(stats?.totalEarningsThisMonth || 0)}
              icon={DollarSign}
              iconColor="bg-green-500"
              linkHref="/analytics"
            />
            <StatsCard
              title="Active Projects"
              value={statsLoading ? "Loading..." : stats?.activeProjects}
              icon={FolderOpen}
              iconColor="bg-purple-500"
              linkHref="/projects"
            />
            <StatsCard
              title="Total Clients"
              value={statsLoading ? "Loading..." : stats?.totalClients}
              icon={Users}
              iconColor="bg-yellow-500"
              linkHref="/clients"
            />
          </div>

          {/* Current Timer */}
          <div className="mt-8">
            <TimerControl />
          </div>

          {/* Time Analytics & Invoices */}
          <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-2">
            <TimeChart data={timeDistribution || []} isLoading={distributionLoading} />

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Recent Invoices</CardTitle>
                <Button asChild size="sm">
                  <Link href="/invoices/new">
                    <Plus className="-ml-1 mr-2 h-4 w-4" />
                    New Invoice
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <InvoiceTable
                  invoices={(invoices || []).slice(0, 3)}
                  clients={clients || []}
                  onViewInvoice={handleViewInvoice}
                  onEditInvoice={handleEditInvoice}
                  onDeleteInvoice={handleDeleteInvoice}
                  onDownloadInvoice={handleDownloadInvoice}
                />
                <div className="mt-4 text-center">
                  <Link href="/invoices">
                    <a className="text-sm font-medium text-blue-600 hover:text-blue-500">
                      View all invoices
                    </a>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Time Entries */}
          <div className="mt-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Recent Time Entries</CardTitle>
                <Link href="/time-tracking">
                  <a className="text-sm font-medium text-blue-600 hover:text-blue-500">
                    View all entries
                  </a>
                </Link>
              </CardHeader>
              <CardContent>
                <TimeEntryTable
                  timeEntries={(timeEntries || []).slice(0, 5)}
                  projects={projects || []}
                  clients={clients || []}
                  onEditEntry={handleEditTimeEntry}
                  onDeleteEntry={handleDeleteTimeEntry}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Delete Time Entry Dialog */}
      <AlertDialog open={showDeleteTimeEntryDialog} onOpenChange={setShowDeleteTimeEntryDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this time entry. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTimeEntry} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Invoice Dialog */}
      <AlertDialog open={showDeleteInvoiceDialog} onOpenChange={setShowDeleteInvoiceDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this invoice. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteInvoice} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
