import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TimeChart } from "@/components/dashboard/time-chart";
import { formatMonth, formatCurrency } from "@/lib/format";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

export default function Analytics() {
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear.toString());
  const [selectedMonth, setSelectedMonth] = useState("all");
  
  // Get date range based on selected month/year
  const getDateRange = () => {
    const year = parseInt(selectedYear);
    
    if (selectedMonth === "all") {
      // Full year
      return {
        startDate: new Date(year, 0, 1),
        endDate: new Date(year, 11, 31, 23, 59, 59)
      };
    } else {
      // Specific month
      const month = parseInt(selectedMonth);
      const lastDay = new Date(year, month + 1, 0).getDate();
      return {
        startDate: new Date(year, month, 1),
        endDate: new Date(year, month, lastDay, 23, 59, 59)
      };
    }
  };
  
  const { startDate, endDate } = getDateRange();
  
  // Fetch time distribution
  const { data: timeDistribution = [], isLoading: distributionLoading } = useQuery({
    queryKey: ["/api/analytics/time-distribution", { startDate, endDate }],
    queryFn: async () => {
      const response = await fetch(`/api/analytics/time-distribution?startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`);
      if (!response.ok) throw new Error("Failed to fetch time distribution");
      return response.json();
    }
  });
  
  // Fetch monthly earnings
  const { data: monthlyEarnings = [], isLoading: earningsLoading } = useQuery({
    queryKey: ["/api/analytics/monthly-earnings", { year: selectedYear }],
    queryFn: async () => {
      const response = await fetch(`/api/analytics/monthly-earnings?year=${selectedYear}`);
      if (!response.ok) throw new Error("Failed to fetch monthly earnings");
      return response.json();
    }
  });
  
  // Fetch overall stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/analytics/stats"],
  });
  
  // Transform time distribution for chart
  const processedTimeData = timeDistribution.map(item => ({
    ...item,
    duration: Math.round(item.duration / 3600 * 10) / 10 // Convert seconds to hours
  }));
  
  // Transform monthly earnings for the bar chart
  const earningsData = monthlyEarnings.map(item => ({
    month: formatMonth(item.month),
    amount: item.amount,
    monthIndex: item.month
  })).sort((a, b) => a.monthIndex - b.monthIndex);
  
  // Filter earnings data by month if specific month is selected
  const displayedEarningsData = selectedMonth === "all" 
    ? earningsData 
    : earningsData.filter(item => item.monthIndex === parseInt(selectedMonth));
  
  // Bar chart colors
  const getBarColor = (amount: number) => {
    return "#3B82F6"; // blue-500
  };
  
  return (
    <div className="flex-1 relative pb-8 z-0 overflow-y-auto">
      {/* Page header */}
      <div className="bg-white shadow">
        <div className="px-4 sm:px-6 lg:max-w-6xl lg:mx-auto lg:px-8">
          <div className="py-6 md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Analytics
              </h2>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Date filters */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Time Period</CardTitle>
              <CardDescription>
                Select the time period for your analytics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="w-full sm:w-1/3">
                  <Select
                    value={selectedYear}
                    onValueChange={setSelectedYear}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 5 }, (_, i) => currentYear - i).map(year => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full sm:w-1/3">
                  <Select
                    value={selectedMonth}
                    onValueChange={setSelectedMonth}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select month" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Months</SelectItem>
                      {Array.from({ length: 12 }, (_, i) => (
                        <SelectItem key={i} value={i.toString()}>
                          {formatMonth(i)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Time and Earnings Charts */}
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 mb-8">
            {/* Time Distribution Chart */}
            <TimeChart 
              data={processedTimeData} 
              isLoading={distributionLoading} 
            />

            {/* Earnings Chart */}
            <Card>
              <CardHeader>
                <CardTitle>
                  {selectedMonth === "all" 
                    ? `Monthly Earnings (${selectedYear})` 
                    : `Earnings for ${formatMonth(parseInt(selectedMonth))} ${selectedYear}`}
                </CardTitle>
                <CardDescription>
                  Revenue breakdown by month
                </CardDescription>
              </CardHeader>
              <CardContent className="h-72">
                {earningsLoading ? (
                  <div className="h-full flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : displayedEarningsData.length === 0 ? (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-muted-foreground">No earnings data available for the selected period</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={displayedEarningsData}
                      margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis 
                        dataKey="month" 
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis 
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(value) => `$${value}`}
                      />
                      <Tooltip 
                        formatter={(value) => [`$${value}`, "Revenue"]}
                        labelFormatter={(label) => `${label}`}
                      />
                      <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                        {displayedEarningsData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={getBarColor(entry.amount)} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Summary Statistics */}
          <Card>
            <CardHeader>
              <CardTitle>Summary Statistics</CardTitle>
              <CardDescription>
                {selectedMonth === "all" 
                  ? `Overall performance for ${selectedYear}` 
                  : `Performance for ${formatMonth(parseInt(selectedMonth))} ${selectedYear}`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="bg-gray-50 p-6 rounded-lg text-center">
                    <h3 className="text-xl font-bold text-gray-900">
                      {stats?.totalHoursThisMonth || 0}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Hours Tracked</p>
                  </div>
                  <div className="bg-gray-50 p-6 rounded-lg text-center">
                    <h3 className="text-xl font-bold text-gray-900">
                      {formatCurrency(stats?.totalEarningsThisMonth || 0)}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Total Revenue</p>
                  </div>
                  <div className="bg-gray-50 p-6 rounded-lg text-center">
                    <h3 className="text-xl font-bold text-gray-900">
                      {stats?.totalHoursThisMonth && stats?.totalEarningsThisMonth
                        ? formatCurrency(stats?.totalEarningsThisMonth / stats?.totalHoursThisMonth)
                        : "$0.00"}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Average Hourly Rate</p>
                  </div>
                  <div className="bg-gray-50 p-6 rounded-lg text-center">
                    <h3 className="text-xl font-bold text-gray-900">
                      {timeDistribution?.length || 0}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Active Projects</p>
                  </div>
                </div>
              )}
              
              {/* Additional insights could be added here */}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
