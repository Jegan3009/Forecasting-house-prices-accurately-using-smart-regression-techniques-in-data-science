import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { 
  Plus, 
  FileDown, 
  ArrowLeft, 
  Calendar, 
  DollarSign, 
  X, 
  Save
} from "lucide-react";
import { InvoiceTable } from "@/components/invoices/invoice-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InvoicePdf, generateInvoicePdf } from "@/components/invoices/invoice-pdf";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { 
  Invoice, Client, Project, TimeEntry, InvoiceItem, 
  invoiceFormSchema, Settings
} from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { formatCurrency } from "@/lib/format";

// Invoice interface with optional id for new invoices
interface InvoiceFormData extends z.infer<typeof invoiceFormSchema> {
  id?: number;
  timeEntryIds?: number[];
}

interface InvoicesProps {
  invoiceId?: string;
  edit?: boolean;
  download?: boolean;
}

export default function Invoices({ invoiceId, edit, download }: InvoicesProps) {
  const [location, navigate] = useLocation();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [selectedClient, setSelectedClient] = useState<number | null>(null);
  const [selectedTimeEntries, setSelectedTimeEntries] = useState<number[]>([]);
  const { toast } = useToast();

  // Fetch invoices
  const { data: invoices = [], isLoading: invoicesLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  // Fetch clients
  const { data: clients = [], isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Fetch projects
  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Fetch unbilled time entries
  const { data: unbilledEntries = [], isLoading: entriesLoading } = useQuery<TimeEntry[]>({
    queryKey: ["/api/time-entries", { unbilled: true }],
    enabled: showAddDialog,
  });

  // Fetch settings
  const { data: settings } = useQuery<Settings>({
    queryKey: ["/api/settings"],
  });

  // Fetch specific invoice if we have an ID
  const { data: specificInvoice, isLoading: specificInvoiceLoading } = useQuery<Invoice>({
    queryKey: ["/api/invoices", invoiceId],
    enabled: !!invoiceId,
  });

  // Fetch specific client for an invoice
  const { data: invoiceClient } = useQuery<Client>({
    queryKey: ["/api/clients", specificInvoice?.clientId],
    enabled: !!specificInvoice?.clientId,
  });

  // Create invoice mutation
  const invoiceMutation = useMutation({
    mutationFn: async (data: InvoiceFormData) => {
      const { id, timeEntryIds, ...formData } = data;
      
      if (id) {
        // Update existing invoice
        const response = await apiRequest("PUT", `/api/invoices/${id}`, { 
          ...formData,
          timeEntryIds 
        });
        return response.json();
      } else {
        // Create new invoice
        const response = await apiRequest("POST", "/api/invoices", { 
          ...formData,
          timeEntryIds 
        });
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      setShowAddDialog(false);
      toast({
        title: selectedInvoice ? "Invoice updated" : "Invoice created",
        description: selectedInvoice
          ? "Your invoice has been updated successfully."
          : "Your invoice has been created successfully.",
      });
      setSelectedInvoice(null);
      setInvoiceItems([]);
      setSelectedTimeEntries([]);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${selectedInvoice ? "update" : "create"} invoice: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete invoice mutation
  const deleteInvoiceMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/invoices/${id}`);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      setShowDeleteDialog(false);
      toast({
        title: "Invoice deleted",
        description: "The invoice has been deleted successfully.",
      });
      setSelectedInvoice(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete invoice: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Form definition
  const form = useForm<z.infer<typeof invoiceFormSchema>>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      userId: 1, // Default to demo user
      clientId: 0,
      invoiceNumber: "",
      issueDate: new Date(),
      dueDate: new Date(new Date().setDate(new Date().getDate() + 30)), // 30 days from now
      status: "pending",
      totalAmount: "0",
      notes: "",
      items: []
    },
  });

  const getNextInvoiceNumber = () => {
    const prefix = settings?.invoicePrefix || "INV-";
    const year = new Date().getFullYear();
    
    if (invoices && invoices.length > 0) {
      // Find the highest number in existing invoices
      const numbers = invoices
        .map(inv => {
          const match = inv.invoiceNumber.match(new RegExp(`^${prefix}${year}-(\\d+)$`));
          return match ? parseInt(match[1]) : 0;
        })
        .filter(num => !isNaN(num));
      
      const highestNumber = Math.max(0, ...numbers);
      return `${prefix}${year}-${String(highestNumber + 1).padStart(3, '0')}`;
    }
    
    return `${prefix}${year}-001`;
  };

  // Initialize form for new invoice
  const initNewInvoiceForm = () => {
    setSelectedInvoice(null);
    setInvoiceItems([]);
    setSelectedTimeEntries([]);
    
    form.reset({
      userId: 1,
      clientId: 0,
      invoiceNumber: getNextInvoiceNumber(),
      issueDate: new Date(),
      dueDate: new Date(new Date().setDate(new Date().getDate() + 30)),
      status: "pending",
      totalAmount: "0",
      notes: settings?.defaultInvoiceNotes || "",
      items: []
    });
    
    setShowAddDialog(true);
  };

  // Handle view invoice
  const handleViewInvoice = (invoice: Invoice) => {
    navigate(`/invoices/${invoice.id}`);
  };

  // Handle edit invoice
  const handleEditInvoice = (invoice: Invoice) => {
    navigate(`/invoices/edit/${invoice.id}`);
  };

  // Handle delete invoice
  const handleDeleteInvoice = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setShowDeleteDialog(true);
  };

  // Handle download invoice
  const handleDownloadInvoice = (invoice: Invoice) => {
    navigate(`/invoices/${invoice.id}/download`);
  };

  // Handle client change
  const handleClientChange = (clientId: string) => {
    setSelectedClient(parseInt(clientId));
    form.setValue("clientId", parseInt(clientId));
  };

  // Calculate invoice total
  const calculateTotal = () => {
    const total = invoiceItems.reduce((sum, item) => sum + item.amount, 0);
    form.setValue("totalAmount", total.toFixed(2));
    return total;
  };

  // Add a new empty line item
  const addLineItem = () => {
    setInvoiceItems([
      ...invoiceItems,
      { description: "", quantity: 1, rate: 0, amount: 0 }
    ]);
  };

  // Remove a line item
  const removeLineItem = (index: number) => {
    const newItems = [...invoiceItems];
    newItems.splice(index, 1);
    setInvoiceItems(newItems);
    form.setValue("items", newItems);
    calculateTotal();
  };

  // Update a line item
  const updateLineItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    const newItems = [...invoiceItems];
    newItems[index] = { ...newItems[index], [field]: value };
    
    // Recalculate amount if quantity or rate changes
    if (field === "quantity" || field === "rate") {
      const quantity = field === "quantity" ? Number(value) : newItems[index].quantity;
      const rate = field === "rate" ? Number(value) : newItems[index].rate;
      newItems[index].amount = quantity * rate;
    }
    
    setInvoiceItems(newItems);
    form.setValue("items", newItems);
    calculateTotal();
  };

  // Toggle a time entry selection
  const toggleTimeEntry = (entryId: number, projectHourlyRate: number) => {
    const isSelected = selectedTimeEntries.includes(entryId);
    let newSelectedEntries: number[];
    
    if (isSelected) {
      newSelectedEntries = selectedTimeEntries.filter(id => id !== entryId);
    } else {
      newSelectedEntries = [...selectedTimeEntries, entryId];
    }
    
    setSelectedTimeEntries(newSelectedEntries);
    
    // Generate invoice items from selected time entries
    const newInvoiceItems: InvoiceItem[] = [];
    const entriesByProject: Record<number, { entries: TimeEntry[], duration: number }> = {};
    
    // Group entries by project
    newSelectedEntries.forEach(id => {
      const entry = unbilledEntries.find(e => e.id === id);
      if (entry && entry.duration) {
        if (!entriesByProject[entry.projectId]) {
          entriesByProject[entry.projectId] = { entries: [], duration: 0 };
        }
        entriesByProject[entry.projectId].entries.push(entry);
        entriesByProject[entry.projectId].duration += entry.duration;
      }
    });
    
    // Create invoice items for each project
    Object.entries(entriesByProject).forEach(([projectId, data]) => {
      const project = projects.find(p => p.id === parseInt(projectId));
      if (project) {
        const hours = data.duration / 3600; // Convert seconds to hours
        const rate = Number(project.hourlyRate) || Number(settings?.defaultHourlyRate) || 50;
        const amount = hours * rate;
        
        newInvoiceItems.push({
          description: `${project.name} (${hours.toFixed(2)} hours)`,
          quantity: hours,
          rate: rate,
          amount: amount
        });
      }
    });
    
    setInvoiceItems(newInvoiceItems);
    form.setValue("items", newInvoiceItems);
    calculateTotal();
  };

  // Handle form submission
  const onSubmit = (data: z.infer<typeof invoiceFormSchema>) => {
    invoiceMutation.mutate({
      ...data,
      id: selectedInvoice?.id,
      items: invoiceItems,
      timeEntryIds: selectedTimeEntries
    });
  };

  // Handle delete confirmation
  const confirmDelete = () => {
    if (selectedInvoice) {
      deleteInvoiceMutation.mutate(selectedInvoice.id);
    }
  };

  // Load invoice data for editing
  useEffect(() => {
    if ((edit || download) && specificInvoice && !specificInvoiceLoading) {
      setSelectedInvoice(specificInvoice);
      setInvoiceItems(specificInvoice.items);
      
      form.reset({
        userId: specificInvoice.userId,
        clientId: specificInvoice.clientId,
        invoiceNumber: specificInvoice.invoiceNumber,
        issueDate: new Date(specificInvoice.issueDate),
        dueDate: new Date(specificInvoice.dueDate),
        status: specificInvoice.status,
        totalAmount: specificInvoice.totalAmount.toString(),
        notes: specificInvoice.notes || "",
        items: specificInvoice.items
      });
      
      if (edit) {
        setShowAddDialog(true);
      }
    }
  }, [edit, download, specificInvoice, specificInvoiceLoading]);

  // Handle PDF download
  useEffect(() => {
    if (download && specificInvoice && invoiceClient && settings) {
      const doc = generateInvoicePdf({
        invoice: specificInvoice,
        client: invoiceClient,
        settings: settings
      });
      
      doc.save(`Invoice-${specificInvoice.invoiceNumber}.pdf`);
      navigate("/invoices", { replace: true });
    }
  }, [download, specificInvoice, invoiceClient, settings]);

  // Render invoice detail view
  if (invoiceId && !edit && !download) {
    return (
      <div className="flex-1 relative pb-8 z-0 overflow-y-auto">
        <div className="bg-white shadow">
          <div className="px-4 sm:px-6 lg:max-w-6xl lg:mx-auto lg:px-8">
            <div className="py-6 md:flex md:items-center md:justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center">
                  <Button
                    variant="ghost"
                    onClick={() => navigate("/invoices")}
                    className="mr-2"
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                  <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Invoice {specificInvoice?.invoiceNumber}
                  </h2>
                </div>
              </div>
              <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
                {specificInvoice && invoiceClient && settings && (
                  <InvoicePdf
                    invoice={specificInvoice}
                    client={invoiceClient}
                    settings={settings}
                  />
                )}
                <Button onClick={() => {
                  if (specificInvoice) {
                    handleEditInvoice(specificInvoice);
                  }
                }}>
                  Edit Invoice
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            {specificInvoiceLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : specificInvoice && invoiceClient ? (
              <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                <div className="px-4 py-5 sm:px-6 flex justify-between">
                  <div>
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Invoice Details</h3>
                    <p className="mt-1 max-w-2xl text-sm text-gray-500">
                      {format(new Date(specificInvoice.issueDate), "MMMM d, yyyy")}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full
                      ${specificInvoice.status === 'paid' ? 'bg-green-100 text-green-800' : 
                      specificInvoice.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'}`}
                    >
                      {specificInvoice.status.charAt(0).toUpperCase() + specificInvoice.status.slice(1)}
                    </div>
                  </div>
                </div>
                <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
                  <dl className="sm:divide-y sm:divide-gray-200">
                    <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                      <dt className="text-sm font-medium text-gray-500">Invoice number</dt>
                      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                        {specificInvoice.invoiceNumber}
                      </dd>
                    </div>
                    <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                      <dt className="text-sm font-medium text-gray-500">Client</dt>
                      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                        {invoiceClient.name}
                        {invoiceClient.company && ` (${invoiceClient.company})`}
                      </dd>
                    </div>
                    <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                      <dt className="text-sm font-medium text-gray-500">Issue date</dt>
                      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                        {format(new Date(specificInvoice.issueDate), "MMMM d, yyyy")}
                      </dd>
                    </div>
                    <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                      <dt className="text-sm font-medium text-gray-500">Due date</dt>
                      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                        {format(new Date(specificInvoice.dueDate), "MMMM d, yyyy")}
                      </dd>
                    </div>
                    <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                      <dt className="text-sm font-medium text-gray-500">Total amount</dt>
                      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2 font-medium">
                        {formatCurrency(Number(specificInvoice.totalAmount))}
                      </dd>
                    </div>
                  </dl>
                </div>

                <div className="px-4 py-5 sm:px-6 border-t border-gray-200">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Invoice Items</h3>
                </div>
                <div className="border-t border-gray-200">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Description
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Quantity
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Rate
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {specificInvoice.items.map((item, index) => (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-normal text-sm text-gray-900">
                            {item.description}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">
                            {item.quantity}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">
                            {formatCurrency(item.rate)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-medium">
                            {formatCurrency(item.amount)}
                          </td>
                        </tr>
                      ))}
                      <tr className="bg-gray-50">
                        <td colSpan={3} className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                          Total
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                          {formatCurrency(Number(specificInvoice.totalAmount))}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {specificInvoice.notes && (
                  <div className="px-4 py-5 sm:px-6 border-t border-gray-200">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Notes</h3>
                    <div className="mt-2 max-w-xl text-sm text-gray-500">
                      <p>{specificInvoice.notes}</p>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">Invoice not found</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Render invoices list view
  return (
    <div className="flex-1 relative pb-8 z-0 overflow-y-auto">
      {/* Page header */}
      <div className="bg-white shadow">
        <div className="px-4 sm:px-6 lg:max-w-6xl lg:mx-auto lg:px-8">
          <div className="py-6 md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Invoices
              </h2>
            </div>
            <div className="mt-4 flex md:mt-0 md:ml-4">
              <Button onClick={initNewInvoiceForm}>
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                New Invoice
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle>All Invoices</CardTitle>
              <CardDescription>
                Manage your client invoices and billing
              </CardDescription>
            </CardHeader>
            <CardContent>
              {invoicesLoading ? (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : (
                <InvoiceTable
                  invoices={invoices}
                  clients={clients}
                  onViewInvoice={handleViewInvoice}
                  onEditInvoice={handleEditInvoice}
                  onDeleteInvoice={handleDeleteInvoice}
                  onDownloadInvoice={handleDownloadInvoice}
                />
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add/Edit Invoice Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedInvoice ? "Edit Invoice" : "Create New Invoice"}</DialogTitle>
            <DialogDescription>
              {selectedInvoice
                ? "Make changes to your invoice here."
                : "Create a new invoice for your client."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="clientId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client</FormLabel>
                      <FormControl>
                        <Select
                          value={field.value.toString()}
                          onValueChange={handleClientChange}
                          disabled={!!selectedInvoice}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select a client" />
                          </SelectTrigger>
                          <SelectContent>
                            {clientsLoading ? (
                              <SelectItem value="loading" disabled>
                                Loading clients...
                              </SelectItem>
                            ) : (
                              clients.map((client) => (
                                <SelectItem key={client.id} value={client.id.toString()}>
                                  {client.name} {client.company ? `(${client.company})` : ""}
                                </SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="invoiceNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Invoice Number</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Issue Date</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                          <Input
                            type="date"
                            className="pl-10"
                            value={field.value ? format(field.value, "yyyy-MM-dd") : ""}
                            onChange={(e) => {
                              field.onChange(e.target.value ? new Date(e.target.value) : undefined);
                            }}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Due Date</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                          <Input
                            type="date"
                            className="pl-10"
                            value={field.value ? format(field.value, "yyyy-MM-dd") : ""}
                            onChange={(e) => {
                              field.onChange(e.target.value ? new Date(e.target.value) : undefined);
                            }}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <FormControl>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="paid">Paid</SelectItem>
                            <SelectItem value="overdue">Overdue</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {!selectedInvoice && selectedClient && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Time Entries</CardTitle>
                    <CardDescription>
                      Select time entries to include in this invoice
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {entriesLoading ? (
                      <div className="flex justify-center py-4">
                        <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary"></div>
                      </div>
                    ) : unbilledEntries.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No unbilled time entries available</p>
                    ) : (
                      <div className="space-y-4">
                        {projects
                          .filter(project => unbilledEntries.some(entry => entry.projectId === project.id))
                          .map(project => {
                            const projectEntries = unbilledEntries.filter(entry => entry.projectId === project.id);
                            if (projectEntries.length === 0) return null;
                            
                            return (
                              <div key={project.id} className="border rounded-md p-4">
                                <h4 className="font-medium mb-2">{project.name}</h4>
                                <div className="space-y-2">
                                  {projectEntries.map(entry => {
                                    const isSelected = selectedTimeEntries.includes(entry.id);
                                    const startDate = new Date(entry.startTime);
                                    let duration = "In progress";
                                    
                                    if (entry.duration) {
                                      const hours = Math.floor(entry.duration / 3600);
                                      const minutes = Math.floor((entry.duration % 3600) / 60);
                                      duration = `${hours}h ${minutes}m`;
                                    } else if (entry.endTime) {
                                      const endDate = new Date(entry.endTime);
                                      const durationSeconds = Math.floor((endDate.getTime() - startDate.getTime()) / 1000);
                                      const hours = Math.floor(durationSeconds / 3600);
                                      const minutes = Math.floor((durationSeconds % 3600) / 60);
                                      duration = `${hours}h ${minutes}m`;
                                    }
                                    
                                    return (
                                      <div
                                        key={entry.id}
                                        className={`flex items-center p-2 rounded-md cursor-pointer 
                                        ${isSelected ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50'}`}
                                        onClick={() => toggleTimeEntry(entry.id, Number(project.hourlyRate))}
                                      >
                                        <input
                                          type="checkbox"
                                          checked={isSelected}
                                          onChange={() => {}}
                                          className="h-4 w-4 text-blue-600 rounded"
                                        />
                                        <div className="ml-3 flex-1">
                                          <p className="text-sm font-medium">
                                            {entry.description || "No description"}
                                          </p>
                                          <p className="text-xs text-gray-500">
                                            {format(startDate, "MMM d, yyyy")} • {duration}
                                          </p>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Invoice Items</h3>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addLineItem}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </div>
                <div className="border rounded-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Description
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                          Quantity
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                          Rate
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                          Amount
                        </th>
                        <th scope="col" className="relative px-6 py-3 w-12">
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {invoiceItems.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                            No items added yet
                          </td>
                        </tr>
                      ) : (
                        invoiceItems.map((item, index) => (
                          <tr key={index}>
                            <td className="px-6 py-4">
                              <Input
                                value={item.description}
                                onChange={(e) => updateLineItem(index, "description", e.target.value)}
                                placeholder="Item description"
                              />
                            </td>
                            <td className="px-6 py-4">
                              <Input
                                type="number"
                                min="0"
                                step="0.01"
                                value={item.quantity}
                                onChange={(e) => updateLineItem(index, "quantity", parseFloat(e.target.value) || 0)}
                                className="text-right"
                              />
                            </td>
                            <td className="px-6 py-4">
                              <div className="relative">
                                <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                                <Input
                                  type="number"
                                  min="0"
                                  step="0.01"
                                  value={item.rate}
                                  onChange={(e) => updateLineItem(index, "rate", parseFloat(e.target.value) || 0)}
                                  className="pl-10 text-right"
                                />
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                              {formatCurrency(item.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => removeLineItem(index)}
                                className="h-8 w-8 text-red-500 hover:text-red-700"
                              >
                                <X className="h-4 w-4" />
                                <span className="sr-only">Remove</span>
                              </Button>
                            </td>
                          </tr>
                        ))
                      )}
                      <tr className="bg-gray-50">
                        <td colSpan={3} className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                          Total
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                          {formatCurrency(calculateTotal())}
                        </td>
                        <td></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Additional notes or payment instructions"
                        rows={4}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddDialog(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={invoiceMutation.isPending}>
                  {invoiceMutation.isPending ? (
                    <span className="flex items-center">
                      <span className="mr-2">Saving</span>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                    </span>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      {selectedInvoice ? "Update Invoice" : "Create Invoice"}
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this invoice. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
              disabled={deleteInvoiceMutation.isPending}
            >
              {deleteInvoiceMutation.isPending ? (
                <span className="flex items-center">
                  <span className="mr-2">Deleting</span>
                  <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                </span>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
