import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Plus, Clock, Search, Filter } from "lucide-react";
import { TimerControl } from "@/components/timer/timer-control";
import { TimeEntryTable } from "@/components/time-entries/time-entry-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { TimeEntry, Project, Client, timeEntryFormSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format } from "date-fns";
import { Textarea } from "@/components/ui/textarea";

export default function TimeTracking() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<TimeEntry | null>(null);
  const { toast } = useToast();
  const [location, setLocation] = useLocation();

  // Get the edit parameter from URL
  const params = new URLSearchParams(location.split("?")[1]);
  const editId = params.get("edit");

  // Fetch time entries
  const { data: timeEntries, isLoading: entriesLoading } = useQuery<TimeEntry[]>({
    queryKey: ["/api/time-entries"],
  });

  // Fetch projects
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Fetch clients
  const { data: clients, isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Mutation for creating/updating time entries
  const timeEntryMutation = useMutation({
    mutationFn: async (data: z.infer<typeof timeEntryFormSchema> & { id?: number }) => {
      const { id, ...formData } = data;
      if (id) {
        // Update existing entry
        const response = await apiRequest("PUT", `/api/time-entries/${id}`, formData);
        return response.json();
      } else {
        // Create new entry
        const response = await apiRequest("POST", "/api/time-entries", formData);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      setShowAddDialog(false);
      toast({
        title: selectedEntry ? "Time entry updated" : "Time entry created",
        description: selectedEntry
          ? "Your time entry has been updated successfully."
          : "Your time entry has been created successfully.",
      });
      setSelectedEntry(null);
      // Clear the edit parameter from URL
      if (editId) {
        setLocation("/time-tracking", { replace: true });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${selectedEntry ? "update" : "create"} time entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutation for deleting time entries
  const deleteTimeEntryMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/time-entries/${id}`);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      setShowDeleteDialog(false);
      toast({
        title: "Time entry deleted",
        description: "The time entry has been deleted successfully.",
      });
      setSelectedEntry(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete time entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Form definition
  const form = useForm<z.infer<typeof timeEntryFormSchema>>({
    resolver: zodResolver(timeEntryFormSchema),
    defaultValues: {
      userId: 1, // Default to demo user
      projectId: 0,
      description: "",
      startTime: new Date(),
      endTime: new Date(),
    },
  });

  // Handle edit time entry
  const handleEditEntry = (entry: TimeEntry) => {
    setSelectedEntry(entry);
    form.reset({
      userId: entry.userId,
      projectId: entry.projectId,
      description: entry.description || "",
      startTime: new Date(entry.startTime),
      endTime: entry.endTime ? new Date(entry.endTime) : undefined,
    });
    setShowAddDialog(true);
  };

  // Handle delete time entry
  const handleDeleteEntry = (entry: TimeEntry) => {
    setSelectedEntry(entry);
    setShowDeleteDialog(true);
  };

  // Handle form submission
  const onSubmit = (data: z.infer<typeof timeEntryFormSchema>) => {
    timeEntryMutation.mutate({
      ...data,
      id: selectedEntry?.id,
    });
  };

  // Handle delete confirmation
  const confirmDelete = () => {
    if (selectedEntry) {
      deleteTimeEntryMutation.mutate(selectedEntry.id);
    }
  };

  // Filter time entries based on search term and project filter
  const filteredTimeEntries = timeEntries
    ? timeEntries.filter(
        (entry) => {
          const matchesSearch = !searchTerm || 
            (entry.description && entry.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
            projects?.find(p => p.id === entry.projectId)?.name.toLowerCase().includes(searchTerm.toLowerCase());
          
          const matchesProject = selectedProject === "all" || entry.projectId === parseInt(selectedProject);
          
          return matchesSearch && matchesProject;
        }
      )
    : [];

  // Load time entry for editing from URL parameter
  useEffect(() => {
    if (editId && timeEntries) {
      const entry = timeEntries.find(e => e.id === parseInt(editId));
      if (entry) {
        handleEditEntry(entry);
      }
    }
  }, [editId, timeEntries]);

  return (
    <div className="flex-1 relative pb-8 z-0 overflow-y-auto">
      {/* Page header */}
      <div className="bg-white shadow">
        <div className="px-4 sm:px-6 lg:max-w-6xl lg:mx-auto lg:px-8">
          <div className="py-6 md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Time Tracking
              </h2>
            </div>
            <div className="mt-4 flex md:mt-0 md:ml-4">
              <Button onClick={() => {
                setSelectedEntry(null);
                form.reset({
                  userId: 1,
                  projectId: 0,
                  description: "",
                  startTime: new Date(),
                  endTime: new Date(),
                });
                setShowAddDialog(true);
              }}>
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                Add Time Entry
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Timer Control */}
          <div className="mb-8">
            <TimerControl />
          </div>

          {/* Filters and Search */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search time entries..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <div className="w-full md:w-1/3">
                  <Select
                    value={selectedProject}
                    onValueChange={setSelectedProject}
                  >
                    <SelectTrigger>
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Filter by project" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Projects</SelectItem>
                      {projects?.map((project) => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Time Entries Table */}
          <Card>
            <CardHeader>
              <CardTitle>Time Entries</CardTitle>
              <CardDescription>
                View and manage all your tracked time
              </CardDescription>
            </CardHeader>
            <CardContent>
              {entriesLoading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : (
                <TimeEntryTable
                  timeEntries={filteredTimeEntries}
                  projects={projects || []}
                  clients={clients || []}
                  onEditEntry={handleEditEntry}
                  onDeleteEntry={handleDeleteEntry}
                />
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add/Edit Time Entry Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedEntry ? "Edit Time Entry" : "Add Time Entry"}</DialogTitle>
            <DialogDescription>
              {selectedEntry
                ? "Make changes to your time entry here."
                : "Add a new time entry to track your work."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="projectId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project</FormLabel>
                    <FormControl>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a project" />
                        </SelectTrigger>
                        <SelectContent>
                          {projectsLoading ? (
                            <SelectItem value="loading" disabled>
                              Loading projects...
                            </SelectItem>
                          ) : (
                            projects?.map((project) => (
                              <SelectItem key={project.id} value={project.id.toString()}>
                                {project.name}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="What did you work on?"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date & Time</FormLabel>
                      <FormControl>
                        <Input
                          type="datetime-local"
                          value={field.value ? format(field.value, "yyyy-MM-dd'T'HH:mm") : ""}
                          onChange={(e) => {
                            field.onChange(e.target.value ? new Date(e.target.value) : undefined);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date & Time</FormLabel>
                      <FormControl>
                        <Input
                          type="datetime-local"
                          value={field.value ? format(field.value, "yyyy-MM-dd'T'HH:mm") : ""}
                          onChange={(e) => {
                            field.onChange(e.target.value ? new Date(e.target.value) : undefined);
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Leave empty for ongoing tasks
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddDialog(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={timeEntryMutation.isPending}>
                  {timeEntryMutation.isPending ? (
                    <span className="flex items-center">
                      <span className="mr-2">Saving</span>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                    </span>
                  ) : selectedEntry ? (
                    "Update Entry"
                  ) : (
                    "Add Entry"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this time entry. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
              disabled={deleteTimeEntryMutation.isPending}
            >
              {deleteTimeEntryMutation.isPending ? (
                <span className="flex items-center">
                  <span className="mr-2">Deleting</span>
                  <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                </span>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
