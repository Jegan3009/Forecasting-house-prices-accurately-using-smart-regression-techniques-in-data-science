import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { 
  Home, 
  BarChart4, 
  AreaChart, 
  Lightbulb, 
  Calculator, 
  Table, 
  UploadCloud,
  Download,
  History,
  Hotel,
  Trees,
  Car,
  Train,
  School,
  ShoppingBag,
  HeartPulse,
  Mail
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Mock ML Model to predict house prices
const predictHousePrice = (data: any): { prediction: number, confidence: number } => {
  // This would be replaced with actual ML model prediction
  const basePrice = 250000;
  const sqftFactor = data.squareFootage * 150;
  const bedroomFactor = data.bedrooms * 15000;
  const bathroomFactor = data.bathrooms * 10000;
  const ageFactor = -data.propertyAge * 1000;
  const locationFactor = data.locationScore * 25000;
  const schoolFactor = data.schoolRating * 5000;
  const garageBonus = data.hasGarage ? 15000 : 0;
  const poolBonus = data.hasPool ? 25000 : 0;
  const renovatedBonus = data.isRenovated ? 30000 : 0;
  
  let price = basePrice + sqftFactor + bedroomFactor + bathroomFactor + 
              ageFactor + locationFactor + schoolFactor + 
              garageBonus + poolBonus + renovatedBonus;
  
  // Add some randomness to simulate real-world variance
  const variance = price * 0.05; // 5% variance
  price = price + (Math.random() * variance * 2 - variance);
  
  return {
    prediction: Math.round(price),
    confidence: 0.85 + (Math.random() * 0.1) // Random confidence between 85% and 95%
  };
};

export default function HousePriceForecasting() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("input");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ prediction: number, confidence: number } | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    squareFootage: 2000,
    bedrooms: 3,
    bathrooms: 2,
    propertyAge: 15,
    locationScore: 7, // 1-10 score
    schoolRating: 8, // 1-10 score
    hasGarage: true,
    hasPool: false,
    isRenovated: false
  });
  
  // Comparison properties for the analysis tab
  const [comparisons] = useState([
    { address: "123 Oak St", price: 325000, sqft: 1850, beds: 3, baths: 2 },
    { address: "456 Maple Ave", price: 289000, sqft: 1750, beds: 3, baths: 2 },
    { address: "789 Pine Rd", price: 349000, sqft: 2100, beds: 4, baths: 2.5 },
  ]);
  
  // Handle form input changes
  const handleInputChange = (name: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // Generate prediction
  const handlePredict = () => {
    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const prediction = predictHousePrice(formData);
      setResult(prediction);
      setLoading(false);
      setActiveTab("results");
      
      toast({
        title: "Prediction Complete",
        description: `Estimated house price: ${formatCurrency(prediction.prediction)}`,
      });
    }, 1500);
  };
  
  // Generate PDF report
  const handleDownloadReport = () => {
    toast({
      title: "Report Generated",
      description: "Your house price forecast report has been downloaded.",
    });
  };
  
  return (
    <div className="flex-1 relative pb-8 z-0 overflow-y-auto">
      {/* Page header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 shadow">
        <div className="px-4 sm:px-6 lg:max-w-6xl lg:mx-auto lg:px-8">
          <div className="py-6 md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-white sm:text-3xl sm:truncate">
                House Price Forecasting
              </h2>
              <p className="mt-1 text-gray-300">
                Leverage advanced regression models to predict property values with high accuracy
              </p>
            </div>
            <div className="mt-4 flex md:mt-0 md:ml-4">
              <Button onClick={handleDownloadReport} className="flex items-center">
                <Download className="mr-2 h-4 w-4" />
                Download Report
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-8">
              <TabsTrigger value="input" className="flex items-center">
                <Home className="mr-2 h-4 w-4" />
                Property Details
              </TabsTrigger>
              <TabsTrigger value="results" className="flex items-center">
                <BarChart4 className="mr-2 h-4 w-4" />
                Prediction Results
              </TabsTrigger>
              <TabsTrigger value="analysis" className="flex items-center">
                <AreaChart className="mr-2 h-4 w-4" />
                Market Analysis
              </TabsTrigger>
            </TabsList>
            
            {/* Property Details Input Form */}
            <TabsContent value="input">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Property Information</CardTitle>
                      <CardDescription>
                        Enter details about the property you want to evaluate
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="squareFootage">Square Footage</Label>
                          <Input
                            id="squareFootage"
                            type="number"
                            value={formData.squareFootage}
                            onChange={(e) => handleInputChange('squareFootage', parseInt(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="bedrooms">Bedrooms</Label>
                          <Select 
                            value={formData.bedrooms.toString()} 
                            onValueChange={(value) => handleInputChange('bedrooms', parseInt(value))}
                          >
                            <SelectTrigger id="bedrooms">
                              <SelectValue placeholder="Select bedrooms" />
                            </SelectTrigger>
                            <SelectContent>
                              {[1, 2, 3, 4, 5, 6].map(num => (
                                <SelectItem key={num} value={num.toString()}>
                                  {num} {num === 1 ? 'bedroom' : 'bedrooms'}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="bathrooms">Bathrooms</Label>
                          <Select 
                            value={formData.bathrooms.toString()} 
                            onValueChange={(value) => handleInputChange('bathrooms', parseFloat(value))}
                          >
                            <SelectTrigger id="bathrooms">
                              <SelectValue placeholder="Select bathrooms" />
                            </SelectTrigger>
                            <SelectContent>
                              {[1, 1.5, 2, 2.5, 3, 3.5, 4].map(num => (
                                <SelectItem key={num} value={num.toString()}>
                                  {num} {num === 1 ? 'bathroom' : 'bathrooms'}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="propertyAge">Property Age (years)</Label>
                        <Input
                          id="propertyAge"
                          type="number"
                          value={formData.propertyAge}
                          onChange={(e) => handleInputChange('propertyAge', parseInt(e.target.value))}
                        />
                      </div>
                      
                      <div className="space-y-3">
                        <Label>Location Quality (1-10)</Label>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">Poor</span>
                          <Slider
                            value={[formData.locationScore]}
                            min={1}
                            max={10}
                            step={1}
                            onValueChange={(value) => handleInputChange('locationScore', value[0])}
                            className="flex-1"
                          />
                          <span className="text-sm text-muted-foreground">Excellent</span>
                        </div>
                        <div className="text-center text-sm font-medium">{formData.locationScore}</div>
                      </div>
                      
                      <div className="space-y-3">
                        <Label>School Rating (1-10)</Label>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">Poor</span>
                          <Slider
                            value={[formData.schoolRating]}
                            min={1}
                            max={10}
                            step={1}
                            onValueChange={(value) => handleInputChange('schoolRating', value[0])}
                            className="flex-1"
                          />
                          <span className="text-sm text-muted-foreground">Excellent</span>
                        </div>
                        <div className="text-center text-sm font-medium">{formData.schoolRating}</div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={formData.hasGarage}
                            onCheckedChange={(checked) => handleInputChange('hasGarage', checked)}
                            id="hasGarage"
                          />
                          <Label htmlFor="hasGarage">Has Garage</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={formData.hasPool}
                            onCheckedChange={(checked) => handleInputChange('hasPool', checked)}
                            id="hasPool"
                          />
                          <Label htmlFor="hasPool">Has Pool</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={formData.isRenovated}
                            onCheckedChange={(checked) => handleInputChange('isRenovated', checked)}
                            id="isRenovated"
                          />
                          <Label htmlFor="isRenovated">Recently Renovated</Label>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        onClick={handlePredict} 
                        className="w-full md:w-auto"
                        disabled={loading}
                      >
                        {loading ? (
                          <>
                            <div className="mr-2 h-4 w-4 animate-spin rounded-full border-t-2 border-b-2 border-white"></div>
                            Calculating...
                          </>
                        ) : (
                          <>
                            <Calculator className="mr-2 h-4 w-4" />
                            Generate Price Forecast
                          </>
                        )}
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
                
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Tools & Resources</CardTitle>
                      <CardDescription>
                        Additional features to enhance your property valuation
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Button variant="outline" className="w-full justify-start">
                        <UploadCloud className="mr-2 h-4 w-4" />
                        Import Property Data
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <History className="mr-2 h-4 w-4" />
                        Historical Price Trends
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Table className="mr-2 h-4 w-4" />
                        Comparable Properties
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Lightbulb className="mr-2 h-4 w-4" />
                        Valuation Tips
                      </Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="mt-6">
                    <CardHeader>
                      <CardTitle>Price Factors</CardTitle>
                      <CardDescription>
                        Key elements affecting property value
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Hotel className="mr-2 h-4 w-4 text-blue-600" />
                          <span>Property Size</span>
                        </div>
                        <span className="text-sm font-medium">High Impact</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Trees className="mr-2 h-4 w-4 text-green-600" />
                          <span>Location</span>
                        </div>
                        <span className="text-sm font-medium">High Impact</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <School className="mr-2 h-4 w-4 text-yellow-600" />
                          <span>School Quality</span>
                        </div>
                        <span className="text-sm font-medium">Medium Impact</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Car className="mr-2 h-4 w-4 text-gray-600" />
                          <span>Garage</span>
                        </div>
                        <span className="text-sm font-medium">Medium Impact</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Train className="mr-2 h-4 w-4 text-purple-600" />
                          <span>Transit Access</span>
                        </div>
                        <span className="text-sm font-medium">Medium Impact</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <ShoppingBag className="mr-2 h-4 w-4 text-pink-600" />
                          <span>Amenities</span>
                        </div>
                        <span className="text-sm font-medium">Low Impact</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            {/* Prediction Results Tab */}
            <TabsContent value="results">
              {result ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-2">
                    <Card className="border-2 border-blue-500">
                      <CardHeader className="bg-blue-50">
                        <CardTitle className="flex items-center justify-between">
                          <span>Price Prediction</span>
                          <span className="text-blue-600">{formatCurrency(result.prediction)}</span>
                        </CardTitle>
                        <CardDescription>
                          Based on your property details and current market conditions
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-6">
                        <div className="space-y-6">
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Confidence</span>
                              <span>{Math.round(result.confidence * 100)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div className="bg-blue-600 h-2.5 rounded-full" 
                                style={{ width: `${result.confidence * 100}%` }}></div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                            <div className="bg-gray-50 p-4 rounded-lg text-center">
                              <p className="text-sm text-gray-500">Low Estimate</p>
                              <p className="text-lg font-semibold">{formatCurrency(result.prediction * 0.9)}</p>
                            </div>
                            <div className="bg-blue-50 border-2 border-blue-100 p-4 rounded-lg text-center">
                              <p className="text-sm text-blue-700">Predicted Value</p>
                              <p className="text-lg font-bold text-blue-800">{formatCurrency(result.prediction)}</p>
                            </div>
                            <div className="bg-gray-50 p-4 rounded-lg text-center">
                              <p className="text-sm text-gray-500">High Estimate</p>
                              <p className="text-lg font-semibold">{formatCurrency(result.prediction * 1.1)}</p>
                            </div>
                          </div>
                          
                          <div className="border rounded-lg p-4">
                            <h3 className="font-medium mb-3">Property Details Used</h3>
                            <div className="grid grid-cols-2 gap-4 text-sm md:grid-cols-3">
                              <div>
                                <p className="text-gray-500">Square Footage</p>
                                <p className="font-medium">{formData.squareFootage} sq ft</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Bedrooms</p>
                                <p className="font-medium">{formData.bedrooms}</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Bathrooms</p>
                                <p className="font-medium">{formData.bathrooms}</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Property Age</p>
                                <p className="font-medium">{formData.propertyAge} years</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Location Score</p>
                                <p className="font-medium">{formData.locationScore}/10</p>
                              </div>
                              <div>
                                <p className="text-gray-500">School Rating</p>
                                <p className="font-medium">{formData.schoolRating}/10</p>
                              </div>
                            </div>
                            <div className="mt-3 flex flex-wrap gap-2">
                              {formData.hasGarage && (
                                <span className="px-2 py-1 bg-gray-100 text-xs rounded-full">Garage</span>
                              )}
                              {formData.hasPool && (
                                <span className="px-2 py-1 bg-gray-100 text-xs rounded-full">Pool</span>
                              )}
                              {formData.isRenovated && (
                                <span className="px-2 py-1 bg-gray-100 text-xs rounded-full">Renovated</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <Button variant="outline" onClick={() => setActiveTab("input")}>
                          Modify Details
                        </Button>
                        <Button onClick={handleDownloadReport}>Download Full Report</Button>
                      </CardFooter>
                    </Card>
                  </div>
                  
                  <div>
                    <Card>
                      <CardHeader>
                        <CardTitle>What's Next?</CardTitle>
                        <CardDescription>
                          Steps to take with your property valuation
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                          <h3 className="font-medium flex items-center text-blue-800">
                            <Lightbulb className="mr-2 h-4 w-4" />
                            Insights
                          </h3>
                          <p className="text-sm mt-1 text-blue-600">
                            Your property's estimated value is in the top 20% for your area.
                            Location quality is a major factor influencing this valuation.
                          </p>
                        </div>
                        
                        <div className="space-y-3">
                          <h3 className="font-medium">Recommended Actions</h3>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start">
                              <div className="rounded-full bg-green-100 p-1 mr-2 mt-0.5">
                                <HeartPulse className="h-3 w-3 text-green-600" />
                              </div>
                              Get a professional home inspection to validate condition
                            </li>
                            <li className="flex items-start">
                              <div className="rounded-full bg-green-100 p-1 mr-2 mt-0.5">
                                <HeartPulse className="h-3 w-3 text-green-600" />
                              </div>
                              Consult with a local real estate agent to confirm pricing
                            </li>
                            <li className="flex items-start">
                              <div className="rounded-full bg-green-100 p-1 mr-2 mt-0.5">
                                <HeartPulse className="h-3 w-3 text-green-600" />
                              </div>
                              Consider minor updates that could increase value further
                            </li>
                          </ul>
                        </div>
                        
                        <Button variant="outline" className="w-full justify-start">
                          <Mail className="mr-2 h-4 w-4" />
                          Get Expert Consultation
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <BarChart4 className="h-16 w-16 text-gray-300 mb-4" />
                    <h3 className="text-xl font-medium">No Prediction Results Yet</h3>
                    <p className="text-gray-500 mb-6">Complete the property details form to generate a price forecast</p>
                    <Button onClick={() => setActiveTab("input")}>Go to Property Details</Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            {/* Market Analysis Tab */}
            <TabsContent value="analysis">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Comparative Market Analysis</CardTitle>
                      <CardDescription>
                        How your property compares to similar properties in the area
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="px-4 py-3 text-left">Property</th>
                              <th className="px-4 py-3 text-right">Price</th>
                              <th className="px-4 py-3 text-right">Price/sqft</th>
                              <th className="px-4 py-3 text-center">Sq.Ft.</th>
                              <th className="px-4 py-3 text-center">Bed</th>
                              <th className="px-4 py-3 text-center">Bath</th>
                              <th className="px-4 py-3 text-right">Difference</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result && (
                              <tr className="bg-blue-50 border-b">
                                <td className="px-4 py-3 font-medium">Your Property</td>
                                <td className="px-4 py-3 text-right font-medium">{formatCurrency(result.prediction)}</td>
                                <td className="px-4 py-3 text-right">${Math.round(result.prediction / formData.squareFootage)}</td>
                                <td className="px-4 py-3 text-center">{formData.squareFootage}</td>
                                <td className="px-4 py-3 text-center">{formData.bedrooms}</td>
                                <td className="px-4 py-3 text-center">{formData.bathrooms}</td>
                                <td className="px-4 py-3 text-right">-</td>
                              </tr>
                            )}
                            {comparisons.map((property, index) => (
                              <tr key={index} className="border-b">
                                <td className="px-4 py-3">{property.address}</td>
                                <td className="px-4 py-3 text-right">{formatCurrency(property.price)}</td>
                                <td className="px-4 py-3 text-right">${Math.round(property.price / property.sqft)}</td>
                                <td className="px-4 py-3 text-center">{property.sqft}</td>
                                <td className="px-4 py-3 text-center">{property.beds}</td>
                                <td className="px-4 py-3 text-center">{property.baths}</td>
                                <td className="px-4 py-3 text-right">
                                  {result && (
                                    <span className={result.prediction > property.price ? "text-green-600" : "text-red-600"}>
                                      {result.prediction > property.price ? "+" : "-"}
                                      {formatCurrency(Math.abs(result.prediction - property.price))}
                                    </span>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      
                      <div className="mt-6 p-4 border rounded-lg">
                        <h3 className="font-medium mb-2">Market Insights</h3>
                        <p className="text-sm text-gray-600">
                          {result 
                            ? `Your property is valued ${result.prediction > comparisons[0].price ? "higher" : "lower"} than the average comparable property in this area. 
                               The predicted price of ${formatCurrency(result.prediction)} reflects its 
                               ${formData.squareFootage > comparisons[0].sqft ? "larger size" : "premium features"}.`
                            : "Complete the property details to see how your property compares to the market."}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Price Trends</CardTitle>
                      <CardDescription>
                        Historical and projected market trends
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48 bg-gray-100 rounded-lg flex items-center justify-center mb-4">
                        <p className="text-gray-500 text-sm">Interactive chart will appear here</p>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Area Growth (Last Year)</span>
                            <span className="font-medium text-green-600">+5.2%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-green-500 h-2 rounded-full" style={{ width: "5.2%" }}></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Projected Growth (Next Year)</span>
                            <span className="font-medium text-blue-600">+3.8%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-500 h-2 rounded-full" style={{ width: "3.8%" }}></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Market Liquidity</span>
                            <span className="font-medium">Medium</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "65%" }}></div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}