import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertClientSchema, 
  insertProjectSchema, 
  insertTimeEntrySchema, 
  insertInvoiceSchema,
  insertSettingsSchema,
  insertUserSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();

  // User routes
  apiRouter.post("/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating user" });
    }
  });

  apiRouter.get("/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving user" });
    }
  });

  // Demo user route for easy login
  apiRouter.get("/demo-user", async (req, res) => {
    try {
      const user = await storage.getUserByUsername("demo");
      
      if (!user) {
        return res.status(404).json({ message: "Demo user not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving demo user" });
    }
  });

  // Client routes
  apiRouter.get("/clients", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      const clients = await storage.getClientsByUserId(userId);
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving clients" });
    }
  });

  apiRouter.get("/clients/:id", async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      const client = await storage.getClient(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      res.json(client);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving client" });
    }
  });

  apiRouter.post("/clients", async (req, res) => {
    try {
      const clientData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(clientData);
      res.status(201).json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid client data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating client" });
    }
  });

  apiRouter.put("/clients/:id", async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      const clientData = insertClientSchema.partial().parse(req.body);
      const updatedClient = await storage.updateClient(clientId, clientData);
      
      if (!updatedClient) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      res.json(updatedClient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid client data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating client" });
    }
  });

  apiRouter.delete("/clients/:id", async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      const result = await storage.deleteClient(clientId);
      
      if (!result) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting client" });
    }
  });

  // Project routes
  apiRouter.get("/projects", async (req, res) => {
    try {
      let projects = [];
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      
      if (req.query.clientId) {
        const clientId = parseInt(req.query.clientId as string);
        projects = await storage.getProjectsByClientId(clientId);
      } else {
        projects = await storage.getProjectsByUserId(userId);
      }
      
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving projects" });
    }
  });

  apiRouter.get("/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving project" });
    }
  });

  apiRouter.post("/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating project" });
    }
  });

  apiRouter.put("/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const projectData = insertProjectSchema.partial().parse(req.body);
      const updatedProject = await storage.updateProject(projectId, projectData);
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(updatedProject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating project" });
    }
  });

  apiRouter.delete("/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const result = await storage.deleteProject(projectId);
      
      if (!result) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting project" });
    }
  });

  // Time Entry routes
  apiRouter.get("/time-entries", async (req, res) => {
    try {
      let timeEntries = [];
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      
      if (req.query.projectId) {
        const projectId = parseInt(req.query.projectId as string);
        timeEntries = await storage.getTimeEntriesByProjectId(projectId);
      } else if (req.query.invoiceId) {
        const invoiceId = parseInt(req.query.invoiceId as string);
        timeEntries = await storage.getTimeEntriesByInvoiceId(invoiceId);
      } else if (req.query.startDate && req.query.endDate) {
        const startDate = new Date(req.query.startDate as string);
        const endDate = new Date(req.query.endDate as string);
        timeEntries = await storage.getTimeEntriesByDateRange(userId, startDate, endDate);
      } else if (req.query.unbilled === "true") {
        timeEntries = await storage.getUnbilledTimeEntries(userId);
      } else {
        timeEntries = await storage.getTimeEntriesByUserId(userId);
      }
      
      res.json(timeEntries);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving time entries" });
    }
  });

  apiRouter.get("/time-entries/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const timeEntry = await storage.getTimeEntry(entryId);
      
      if (!timeEntry) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      
      res.json(timeEntry);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving time entry" });
    }
  });

  apiRouter.post("/time-entries", async (req, res) => {
    try {
      const entryData = insertTimeEntrySchema.parse(req.body);
      const timeEntry = await storage.createTimeEntry(entryData);
      res.status(201).json(timeEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating time entry" });
    }
  });

  apiRouter.put("/time-entries/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const entryData = insertTimeEntrySchema.partial().parse(req.body);
      const updatedEntry = await storage.updateTimeEntry(entryId, entryData);
      
      if (!updatedEntry) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      
      res.json(updatedEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating time entry" });
    }
  });

  apiRouter.delete("/time-entries/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const result = await storage.deleteTimeEntry(entryId);
      
      if (!result) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting time entry" });
    }
  });

  // Invoice routes
  apiRouter.get("/invoices", async (req, res) => {
    try {
      let invoices = [];
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      
      if (req.query.clientId) {
        const clientId = parseInt(req.query.clientId as string);
        invoices = await storage.getInvoicesByClientId(clientId);
      } else {
        invoices = await storage.getInvoicesByUserId(userId);
      }
      
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving invoices" });
    }
  });

  apiRouter.get("/invoices/:id", async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving invoice" });
    }
  });

  apiRouter.post("/invoices", async (req, res) => {
    try {
      const invoiceData = insertInvoiceSchema.parse(req.body);
      const invoice = await storage.createInvoice(invoiceData);
      
      // If time entries are provided, update them with the invoice ID
      if (req.body.timeEntryIds && Array.isArray(req.body.timeEntryIds)) {
        for (const entryId of req.body.timeEntryIds) {
          await storage.updateTimeEntry(entryId, { invoiceId: invoice.id });
        }
      }
      
      res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid invoice data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating invoice" });
    }
  });

  apiRouter.put("/invoices/:id", async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      const invoiceData = insertInvoiceSchema.partial().parse(req.body);
      const updatedInvoice = await storage.updateInvoice(invoiceId, invoiceData);
      
      if (!updatedInvoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      res.json(updatedInvoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid invoice data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating invoice" });
    }
  });

  apiRouter.delete("/invoices/:id", async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      // Get time entries associated with this invoice
      const timeEntries = await storage.getTimeEntriesByInvoiceId(invoiceId);
      
      // Update time entries to remove invoice ID
      for (const entry of timeEntries) {
        await storage.updateTimeEntry(entry.id, { invoiceId: undefined });
      }
      
      const result = await storage.deleteInvoice(invoiceId);
      
      if (!result) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting invoice" });
    }
  });

  // Settings routes
  apiRouter.get("/settings", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      const settings = await storage.getSettingsByUserId(userId);
      
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving settings" });
    }
  });

  apiRouter.post("/settings", async (req, res) => {
    try {
      const settingsData = insertSettingsSchema.parse(req.body);
      const settings = await storage.createSettings(settingsData);
      res.status(201).json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating settings" });
    }
  });

  apiRouter.put("/settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const settingsData = insertSettingsSchema.partial().parse(req.body);
      const updatedSettings = await storage.updateSettings(userId, settingsData);
      
      if (!updatedSettings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      
      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating settings" });
    }
  });

  // Analytics routes
  apiRouter.get("/analytics/time-distribution", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : new Date();
      
      const distribution = await storage.getTimeDistributionByProject(userId, startDate, endDate);
      res.json(distribution);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving time distribution" });
    }
  });

  apiRouter.get("/analytics/monthly-earnings", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      const year = req.query.year ? parseInt(req.query.year as string) : new Date().getFullYear();
      
      const earnings = await storage.getMonthlyEarnings(userId, year);
      res.json(earnings);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving monthly earnings" });
    }
  });

  apiRouter.get("/analytics/stats", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1; // Default to demo user
      const stats = await storage.getTotalStatsByUserId(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving statistics" });
    }
  });

  // Mount all API routes under /api prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
