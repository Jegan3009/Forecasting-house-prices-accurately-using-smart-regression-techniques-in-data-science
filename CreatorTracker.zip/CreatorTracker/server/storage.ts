import { 
  users, clients, projects, timeEntries, invoices, settings,
  type User, type InsertUser,
  type Client, type InsertClient, 
  type Project, type InsertProject,
  type TimeEntry, type InsertTimeEntry,
  type Invoice, type InsertInvoice,
  type Settings, type InsertSettings,
  InvoiceItem
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Client operations
  getClient(id: number): Promise<Client | undefined>;
  getClientsByUserId(userId: number): Promise<Client[]>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<Client>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<boolean>;

  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  getProjectsByClientId(clientId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Time Entry operations
  getTimeEntry(id: number): Promise<TimeEntry | undefined>;
  getTimeEntriesByUserId(userId: number): Promise<TimeEntry[]>;
  getTimeEntriesByProjectId(projectId: number): Promise<TimeEntry[]>;
  getTimeEntriesByInvoiceId(invoiceId: number): Promise<TimeEntry[]>;
  getTimeEntriesByDateRange(userId: number, startDate: Date, endDate: Date): Promise<TimeEntry[]>;
  getUnbilledTimeEntries(userId: number): Promise<TimeEntry[]>;
  createTimeEntry(timeEntry: InsertTimeEntry): Promise<TimeEntry>;
  updateTimeEntry(id: number, timeEntry: Partial<TimeEntry>): Promise<TimeEntry | undefined>;
  deleteTimeEntry(id: number): Promise<boolean>;

  // Invoice operations
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoicesByUserId(userId: number): Promise<Invoice[]>;
  getInvoicesByClientId(clientId: number): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, invoice: Partial<Invoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: number): Promise<boolean>;

  // Settings operations
  getSettingsByUserId(userId: number): Promise<Settings | undefined>;
  createSettings(settings: InsertSettings): Promise<Settings>;
  updateSettings(userId: number, settings: Partial<Settings>): Promise<Settings | undefined>;

  // Analytics operations
  getTimeDistributionByProject(userId: number, startDate: Date, endDate: Date): Promise<{ projectId: number, projectName: string, duration: number }[]>;
  getMonthlyEarnings(userId: number, year: number): Promise<{ month: number, amount: number }[]>;
  getTotalStatsByUserId(userId: number): Promise<{ 
    totalHoursThisMonth: number, 
    totalEarningsThisMonth: number, 
    activeProjects: number, 
    totalClients: number 
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clients: Map<number, Client>;
  private projects: Map<number, Project>;
  private timeEntries: Map<number, TimeEntry>;
  private invoices: Map<number, Invoice>;
  private settings: Map<number, Settings>;
  
  private userId: number;
  private clientId: number;
  private projectId: number;
  private timeEntryId: number;
  private invoiceId: number;
  private settingsId: number;

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.projects = new Map();
    this.timeEntries = new Map();
    this.invoices = new Map();
    this.settings = new Map();
    
    this.userId = 1;
    this.clientId = 1;
    this.projectId = 1;
    this.timeEntryId = 1;
    this.invoiceId = 1;
    this.settingsId = 1;

    // Create demo data
    this.seedDemoData();
  }

  private seedDemoData() {
    // Create a demo user
    const demoUser: InsertUser = {
      username: "demo",
      password: "password",
      name: "Sarah Johnson",
      email: "sarah@example.com",
      company: "Content Creator Ltd",
      hourlyRate: "50",
    };
    const user = this.createUser(demoUser);

    // Create demo settings
    this.createSettings({
      userId: user.id,
      companyName: "Content Creator Ltd",
      companyAddress: "123 Creative St, Digital City",
      companyEmail: "sarah@example.com",
      companyPhone: "555-123-4567",
      defaultHourlyRate: "50",
      invoicePrefix: "INV-",
      defaultInvoiceNotes: "Thank you for your business!",
    });

    // Create demo clients
    const acmeClient = this.createClient({
      userId: user.id,
      name: "Acme Studios",
      company: "Acme Studios Inc.",
      email: "contact@acmestudios.com",
      phone: "555-111-2222",
      address: "456 Media Blvd, Content City",
    });

    const techClient = this.createClient({
      userId: user.id,
      name: "TechCorp Inc.",
      company: "TechCorp Incorporated",
      email: "projects@techcorp.com",
      phone: "555-333-4444",
      address: "789 Tech Park, Innovation Valley",
    });

    const creativeClient = this.createClient({
      userId: user.id,
      name: "Creative Media",
      company: "Creative Media Group",
      email: "hello@creativemedia.com",
      phone: "555-555-6666",
      address: "101 Art Street, Design District",
    });

    // Create demo projects
    const youtubeProject = this.createProject({
      userId: user.id,
      clientId: acmeClient.id,
      name: "YouTube Video Production",
      description: "Monthly video content production",
      hourlyRate: "60",
      active: true,
    });

    const websiteProject = this.createProject({
      userId: user.id,
      clientId: techClient.id,
      name: "Client Website Redesign",
      description: "Complete website redesign and development",
      hourlyRate: "75",
      active: true,
    });

    const podcastProject = this.createProject({
      userId: user.id,
      clientId: creativeClient.id,
      name: "Podcast Editing",
      description: "Weekly podcast editing and production",
      hourlyRate: "55",
      active: true,
    });

    const contentProject = this.createProject({
      userId: user.id,
      clientId: techClient.id,
      name: "Content Writing",
      description: "Blog posts and technical documentation",
      hourlyRate: "45",
      active: true,
    });

    // Create demo time entries - YouTube
    const currentDate = new Date();
    
    this.createTimeEntry({
      userId: user.id,
      projectId: youtubeProject.id,
      description: "Editing monthly recap video",
      startTime: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), 9, 30),
      endTime: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), 12, 15),
    });

    // Create demo time entries - Website
    const yesterdayDate = new Date(currentDate);
    yesterdayDate.setDate(currentDate.getDate() - 1);
    
    this.createTimeEntry({
      userId: user.id,
      projectId: websiteProject.id,
      description: "Homepage wireframes",
      startTime: new Date(yesterdayDate.getFullYear(), yesterdayDate.getMonth(), yesterdayDate.getDate(), 14, 0),
      endTime: new Date(yesterdayDate.getFullYear(), yesterdayDate.getMonth(), yesterdayDate.getDate(), 17, 30),
    });

    // Create demo time entries - Podcast
    this.createTimeEntry({
      userId: user.id,
      projectId: podcastProject.id,
      description: "Episode 42 post-production",
      startTime: new Date(yesterdayDate.getFullYear(), yesterdayDate.getMonth(), yesterdayDate.getDate(), 9, 0),
      endTime: new Date(yesterdayDate.getFullYear(), yesterdayDate.getMonth(), yesterdayDate.getDate(), 13, 15),
    });

    // Create demo invoices
    const acmeInvoiceItems: InvoiceItem[] = [
      {
        description: "Video production services",
        quantity: 10,
        rate: 60,
        amount: 600
      },
      {
        description: "Additional editing work",
        quantity: 5,
        rate: 65,
        amount: 325
      },
      {
        description: "Stock music licenses",
        quantity: 3,
        rate: 108.33,
        amount: 325
      }
    ];

    this.createInvoice({
      userId: user.id,
      clientId: acmeClient.id,
      invoiceNumber: "INV-2023-056",
      issueDate: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - 15),
      dueDate: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 15),
      status: "paid",
      totalAmount: "1250",
      notes: "Thank you for your business!",
      items: acmeInvoiceItems
    });

    const techInvoiceItems: InvoiceItem[] = [
      {
        description: "Website design",
        quantity: 20,
        rate: 75,
        amount: 1500
      },
      {
        description: "Content writing",
        quantity: 10,
        rate: 45,
        amount: 450
      },
      {
        description: "SEO optimization",
        quantity: 5,
        rate: 90,
        amount: 450
      }
    ];

    this.createInvoice({
      userId: user.id,
      clientId: techClient.id,
      invoiceNumber: "INV-2023-055",
      issueDate: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - 5),
      dueDate: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 25),
      status: "pending",
      totalAmount: "2400",
      notes: "Net 30 payment terms",
      items: techInvoiceItems
    });

    const creativeInvoiceItems: InvoiceItem[] = [
      {
        description: "Podcast editing - Episodes 40-41",
        quantity: 8,
        rate: 55,
        amount: 440
      },
      {
        description: "Audio cleanup and mastering",
        quantity: 5,
        rate: 65,
        amount: 325
      },
      {
        description: "Show notes creation",
        quantity: 2,
        rate: 55,
        amount: 110
      }
    ];

    this.createInvoice({
      userId: user.id,
      clientId: creativeClient.id,
      invoiceNumber: "INV-2023-054",
      issueDate: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - 45),
      dueDate: new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - 15),
      status: "overdue",
      totalAmount: "875",
      notes: "Please pay immediately",
      items: creativeInvoiceItems
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { id, ...user };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Client operations
  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async getClientsByUserId(userId: number): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(
      (client) => client.userId === userId,
    );
  }

  async createClient(client: InsertClient): Promise<Client> {
    const id = this.clientId++;
    const newClient: Client = { id, ...client };
    this.clients.set(id, newClient);
    return newClient;
  }

  async updateClient(id: number, clientData: Partial<Client>): Promise<Client | undefined> {
    const client = await this.getClient(id);
    if (!client) return undefined;
    
    const updatedClient = { ...client, ...clientData };
    this.clients.set(id, updatedClient);
    return updatedClient;
  }

  async deleteClient(id: number): Promise<boolean> {
    return this.clients.delete(id);
  }

  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (project) => project.userId === userId,
    );
  }

  async getProjectsByClientId(clientId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (project) => project.clientId === clientId,
    );
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = this.projectId++;
    const newProject: Project = { id, ...project };
    this.projects.set(id, newProject);
    return newProject;
  }

  async updateProject(id: number, projectData: Partial<Project>): Promise<Project | undefined> {
    const project = await this.getProject(id);
    if (!project) return undefined;
    
    const updatedProject = { ...project, ...projectData };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  // Time Entry operations
  async getTimeEntry(id: number): Promise<TimeEntry | undefined> {
    return this.timeEntries.get(id);
  }

  async getTimeEntriesByUserId(userId: number): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values())
      .filter((entry) => entry.userId === userId)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  async getTimeEntriesByProjectId(projectId: number): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values())
      .filter((entry) => entry.projectId === projectId)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  async getTimeEntriesByInvoiceId(invoiceId: number): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values())
      .filter((entry) => entry.invoiceId === invoiceId)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  async getTimeEntriesByDateRange(userId: number, startDate: Date, endDate: Date): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values())
      .filter((entry) => {
        return entry.userId === userId && 
          new Date(entry.startTime) >= startDate && 
          new Date(entry.startTime) <= endDate;
      })
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  async getUnbilledTimeEntries(userId: number): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values())
      .filter((entry) => entry.userId === userId && !entry.invoiceId)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  async createTimeEntry(timeEntry: InsertTimeEntry): Promise<TimeEntry> {
    const id = this.timeEntryId++;
    
    // Calculate duration if start and end times are provided
    let duration: number | undefined = undefined;
    if (timeEntry.startTime && timeEntry.endTime) {
      duration = Math.floor((new Date(timeEntry.endTime).getTime() - new Date(timeEntry.startTime).getTime()) / 1000);
    }
    
    const newTimeEntry: TimeEntry = { 
      id, 
      ...timeEntry,
      duration,
      invoiceId: undefined
    };
    
    this.timeEntries.set(id, newTimeEntry);
    return newTimeEntry;
  }

  async updateTimeEntry(id: number, entryData: Partial<TimeEntry>): Promise<TimeEntry | undefined> {
    const entry = await this.getTimeEntry(id);
    if (!entry) return undefined;
    
    // Recalculate duration if start or end time is updated
    let updatedEntry = { ...entry, ...entryData };
    
    if ((entryData.startTime || entryData.endTime) && updatedEntry.startTime && updatedEntry.endTime) {
      updatedEntry.duration = Math.floor(
        (new Date(updatedEntry.endTime).getTime() - new Date(updatedEntry.startTime).getTime()) / 1000
      );
    }
    
    this.timeEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteTimeEntry(id: number): Promise<boolean> {
    return this.timeEntries.delete(id);
  }

  // Invoice operations
  async getInvoice(id: number): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async getInvoicesByUserId(userId: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values())
      .filter(invoice => invoice.userId === userId)
      .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
  }

  async getInvoicesByClientId(clientId: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values())
      .filter(invoice => invoice.clientId === clientId)
      .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const id = this.invoiceId++;
    const newInvoice: Invoice = { id, ...invoice };
    this.invoices.set(id, newInvoice);
    return newInvoice;
  }

  async updateInvoice(id: number, invoiceData: Partial<Invoice>): Promise<Invoice | undefined> {
    const invoice = await this.getInvoice(id);
    if (!invoice) return undefined;
    
    const updatedInvoice = { ...invoice, ...invoiceData };
    this.invoices.set(id, updatedInvoice);
    return updatedInvoice;
  }

  async deleteInvoice(id: number): Promise<boolean> {
    return this.invoices.delete(id);
  }

  // Settings operations
  async getSettingsByUserId(userId: number): Promise<Settings | undefined> {
    return Array.from(this.settings.values()).find(
      (setting) => setting.userId === userId,
    );
  }

  async createSettings(settingsData: InsertSettings): Promise<Settings> {
    const id = this.settingsId++;
    const newSettings: Settings = { id, ...settingsData };
    this.settings.set(id, newSettings);
    return newSettings;
  }

  async updateSettings(userId: number, settingsData: Partial<Settings>): Promise<Settings | undefined> {
    const settings = await this.getSettingsByUserId(userId);
    if (!settings) return undefined;
    
    const updatedSettings = { ...settings, ...settingsData };
    this.settings.set(settings.id, updatedSettings);
    return updatedSettings;
  }

  // Analytics operations
  async getTimeDistributionByProject(userId: number, startDate: Date, endDate: Date): Promise<{ projectId: number, projectName: string, duration: number }[]> {
    const entries = await this.getTimeEntriesByDateRange(userId, startDate, endDate);
    const projects = await this.getProjectsByUserId(userId);
    
    // Group by project and sum durations
    const projectMap = new Map<number, number>();
    
    for (const entry of entries) {
      if (entry.duration) {
        const projectId = entry.projectId;
        const currentDuration = projectMap.get(projectId) || 0;
        projectMap.set(projectId, currentDuration + entry.duration);
      }
    }
    
    // Convert to array with project names
    const result = Array.from(projectMap.entries()).map(([projectId, duration]) => {
      const project = projects.find(p => p.id === projectId);
      return {
        projectId,
        projectName: project ? project.name : "Unknown Project",
        duration
      };
    });
    
    return result;
  }

  async getMonthlyEarnings(userId: number, year: number): Promise<{ month: number, amount: number }[]> {
    const invoices = await this.getInvoicesByUserId(userId);
    
    // Filter invoices by year and group by month
    const monthlyEarnings = new Map<number, number>();
    
    for (let month = 0; month < 12; month++) {
      monthlyEarnings.set(month, 0);
    }
    
    for (const invoice of invoices) {
      const invoiceDate = new Date(invoice.issueDate);
      if (invoiceDate.getFullYear() === year) {
        const month = invoiceDate.getMonth();
        const currentAmount = monthlyEarnings.get(month) || 0;
        monthlyEarnings.set(month, currentAmount + Number(invoice.totalAmount));
      }
    }
    
    // Convert to array
    return Array.from(monthlyEarnings.entries()).map(([month, amount]) => ({ month, amount }));
  }

  async getTotalStatsByUserId(userId: number): Promise<{ 
    totalHoursThisMonth: number, 
    totalEarningsThisMonth: number, 
    activeProjects: number, 
    totalClients: number 
  }> {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    
    // Get all time entries for this month
    const timeEntries = await this.getTimeEntriesByDateRange(userId, startOfMonth, endOfMonth);
    
    // Calculate total hours
    const totalSeconds = timeEntries.reduce((total, entry) => total + (entry.duration || 0), 0);
    const totalHoursThisMonth = parseFloat((totalSeconds / 3600).toFixed(1));
    
    // Get all invoices for this month
    const invoices = (await this.getInvoicesByUserId(userId)).filter(
      invoice => {
        const invoiceDate = new Date(invoice.issueDate);
        return invoiceDate >= startOfMonth && invoiceDate <= endOfMonth;
      }
    );
    
    // Calculate total earnings
    const totalEarningsThisMonth = invoices.reduce(
      (total, invoice) => total + Number(invoice.totalAmount), 
      0
    );
    
    // Count active projects
    const projects = await this.getProjectsByUserId(userId);
    const activeProjects = projects.filter(project => project.active).length;
    
    // Count total clients
    const clients = await this.getClientsByUserId(userId);
    const totalClients = clients.length;
    
    return {
      totalHoursThisMonth,
      totalEarningsThisMonth,
      activeProjects,
      totalClients
    };
  }
}

export const storage = new MemStorage();
